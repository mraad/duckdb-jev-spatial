---
type: Ossie Dataset
title: Pipelines
description: Pipelines in the North Sea in various phases.
tags: [ossie, dataset]
generated: {by: geo-ontology/0.1.0, at: '2026-10-04T15:33:49Z'}
source: NorthSea.main.Pipelines
display_field: pipe_name
definition_sha256: a15e6485d3f958b7f1d77acd5aaef54a12a8a0691873fc022d938c2787b03710
sources:
- {id: model, resource: /NorthSea.ossie.yaml, title: Apache Ossie semantic model}
---

Pipelines in the North Sea in various phases.

Ossie dataset over `NorthSea.main.Pipelines`, primary key `OBJECTID`.[^model] Its ontology concept is [Pipelines](../concepts/Pipelines.md).

# Schema

| Field | Type | Description | Values |
|---|---|---|---|
| `OBJECTID` | Integer | Feature identifier (unique per row). |  |
| `country` | String | The country of the pipeline. | coded, see below |
| `current_operator` | String | The current operator | `GASSCO AS`, `EQUINOR ENERGY AS`, `CONOCOPHILLIPS SKANDINAVIA AS`, `AKER BP ASA`, `OKEA ASA`, `A/S NORSKE SHELL`, `VÅR ENERGI ASA`, `UNKNOWN` |
| `current_phase` | String | The current phase of this pipeline | `IN SERVICE`, `DECOMMISSIONED`, `ABANDONED IN PLACE` |
| `dimension` | Float | diameter in inches | `36.0`, `16.0`, `20.0`, `40.0`, `30.0`, `28.0`, `42.0`, `8.0`, `34.0`, `32.0` |
| `from_facility` | String | The originating facility. | `SLEIPNER R`, `KOLLSNES`, `TROLL A`, `GJØA`, `STATFJORD B`, `HEIDRUN`, `HEIMDAL HRP`, `HULDRA`, `KÅRSTØ`, `DRAUPNER E` |
| `main_grouping` | String | main grouping | `Transportation` |
| `pipe_name` | String | pipe name | `36" Gas TROLL A, KOLLSNES`, `34" Oil 36/22-BP, TEESSIDE`, `34" Oil 37/4-BP, 36/22-BP`, `42" Gas ÅSGARD ERB, KÅRSTØ`, `20" Gas TOGI, OSEBERG B`, `16" Oil GJØA, TOR II Y`, `26" Gas SKARV ERB, ÅSGARD T`, `36" Gas Disconnected, EKOFISK S`, `8" Condensate KOLLSNES, STURE`, `20" Oil ULA PP, EKOFISK J` |
| `to_facility` | String | The destination facility | `KOLLSNES`, `MONGSTAD`, `KÅRSTØ`, `STURE`, `EMDEN`, `DRAUPNER S`, `NYHAMNA`, `TOR II Y`, `NORNE/HEIDRUN T`, `HEIMDAL HRP` |
| `PipelinesType` | SmallInteger | pipelines type | coded, see below |
| `geometry` | Polyline geometry | Polyline geometry in EPSG:4326 (longitude, latitude). |  |

# Codes

## `country`

| Code | Value |
|---|---|
| `NO` | Norway |
| `UK` | United Kingdom |
| `DK` | Denmark |
| `NL` | Netherlands |

## `PipelinesType`

| Code | Value |
|---|---|
| `1` | Condensate |
| `2` | Gas |
| `3` | Injection |
| `4` | Oil |
| `0` | Unknown |

# Query hints

## `country`

Use 'country = 'NO'' for 'norway'. Use 'country = 'UK'' for 'united kingdom'. Use 'country = 'DK'' for 'denmark'. Use 'country = 'NL'' for 'netherlands'. NEVER use SQL LIKE in the WHERE clause for the values of the column country.

## `current_operator`

Make sure to uppercase the compared values of the column current_operator in the where clause. For example: given the value >>gassco as<< becomes >>GASSCO AS<<

## `current_phase`

Make sure to uppercase the compared values of the column current_phase in the where clause. For example: given the value >>in service<< becomes >>IN SERVICE<<

## `dimension`

ALWAYS use SQL CAST AS DOUBLE PRECISION when comparing a value with the column dimension. Use 'dimension = cast(36.0 as DOUBLE PRECISION)' for 'diameter in inches is 36.0'.

## `from_facility`

Make sure to uppercase the compared values of the column from_facility in the where clause. For example: given the value >>sleipner r<< becomes >>SLEIPNER R<<

## `main_grouping`

Make sure to use the SQL ILIKE in the WHERE clause for the values of the column main_grouping. For example: given >>main grouping is transportation<< becomes >>main_grouping ILIKE '%Transportation%'<<

## `pipe_name`

Make sure to use the SQL ILIKE in the WHERE clause for the values of the column pipe_name. For example: given >>pipe name is 36"<< becomes >>pipe_name ILIKE '%36"%'<<

## `to_facility`

Make sure to uppercase the compared values of the column to_facility in the where clause. For example: given the value >>kollsnes<< becomes >>KOLLSNES<<

## `PipelinesType`

Use 'PipelinesType = cast(1 as SMALLINT)' for 'condensate pipelines'. Use 'PipelinesType = cast(2 as SMALLINT)' for 'gas pipelines'. Use 'PipelinesType = cast(3 as SMALLINT)' for 'injection pipelines'. Use 'PipelinesType = cast(4 as SMALLINT)' for 'oil pipelines'. Use 'PipelinesType = cast(0 as SMALLINT)' for 'unknown pipelines'. ALWAYS use SQL CAST AS SMALLINT when comparing a value with the column PipelinesType.

[^model]: Apache Ossie semantic model
