---
type: Ossie Dataset
title: Wells
description: Oil and gas wells in the north sea.
tags: [ossie, dataset]
generated: {by: geo-ontology/0.1.0, at: '2026-10-04T15:33:49Z'}
source: NorthSea.main.Wells
temporal: {start: entry_date, end: completion_date}
display_field: well_name
definition_sha256: 62df580d427758ce76fde8037499bdd3e0737edd7653b78180ebb4ab4be36134
sources:
- {id: model, resource: /NorthSea.ossie.yaml, title: Apache Ossie semantic model}
---

Oil and gas wells in the north sea.

Ossie dataset over `NorthSea.main.Wells`, primary key `OBJECTID`.[^model] Its ontology concept is [Wells](../concepts/Wells.md).

# Schema

| Field | Type | Description | Values |
|---|---|---|---|
| `OBJECTID` | Integer | Feature identifier (unique per row). |  |
| `well_name` | String | The name of the well | `22/02b- 14`, `22/14b- 6`, `9/23a- 29`, `22/02b- 13`, `21/23a- 9`, `213/25c- 1`, `21/10- 10`, `25/1-7`, `25/1-8`, `15/9-19` |
| `wellbore_name` | String | wellbore name | `M-1X`, `GERT-1`, `7120/7-1`, `1/3-3`, `25/5-1`, `34/10-37`, `6406/2-1`, `6407/7-7 S`, `25/8-17`, `6406/9-3` |
| `purpose` | String | purpose | `EXPLORATION`, `APPRAISAL`, `HYDROCARBON EXPLORATION`, `WILDCAT`, `PRODUCTION`, `UNKNOWN`, `INJECTION`, `STORAGE`, `APPRAISAL-CCS`, `OTHER` |
| `field_name` | String | The name of the field | `TROLL`, `OSEBERG`, `BALDER`, `GULLFAKS`, `GULLFAKS SØR`, `JOHAN SVERDRUP`, `ÅSGARD`, `SNØHVIT`, `OSEBERG SØR`, `FRIGG` |
| `multilateral` | String | multilateral | `NO` |
| `entry_date` | DateTimeTz | entry date | `1991-04-15 00:00:00`, `1985-10-18 00:00:00`, `2007-10-08 00:00:00`, `2009-10-17 00:00:00`, `1990-10-12 00:00:00`, `1991-06-06 00:00:00`, `1982-01-09 00:00:00`, `1973-12-25 00:00:00`, `1997-01-29 00:00:00`, `1983-03-16 00:00:00` |
| `completion_date` | DateTimeTz | completion date | `1990-05-07 00:00:00`, `1988-10-22 00:00:00`, `1981-11-07 00:00:00`, `1997-04-05 00:00:00`, `1989-03-28 00:00:00`, `2002-12-13 00:00:00`, `2009-10-17 00:00:00`, `1991-09-27 00:00:00`, `1977-10-03 00:00:00`, `1984-06-07 00:00:00` |
| `status` | String | status | `ABANDONED PHASE 3`, `P&A`, `ABANDONED PHASE 1`, `ABANDONED PHASE 2`, `SUSPENDED`, `PLUGGED`, `JUNKED`, `RE-CLASS TO DEV`, `COMPLETED (SHUT IN)`, `COMPLETED (OPERATING)` |
| `water_depth` | Float (meters) | Water depth at the well location, in meters. | `110.0`, `92.964`, `70.0`, `32.004`, `69.0`, `90.5256`, `71.0`, `66.0`, `121.0`, `120.0` |
| `production_facility` | String | production facility | `VARG A`, `MARTIN LINGE A`, `VALEMON`, `FENJA G`, `ORMEN LANGE C`, `BRAGE`, `FOSSEKALL R`, `VIGDIS E`, `ÅSGARD NB` |
| `source` | String | source | coded, see below |
| `well_type` | String | well type | `EXPLORATION` |
| `discovery_wellbore` | String | discovery wellbore | `NO`, `YES` |
| `drilling_operator` | String | drilling operator | `Unknown`, `No Data Available`, `Den Norske Stats Oljeselskap A.S`, `Chrysaor Production (U.K.) Limited`, `Norsk Hydro Produksjon As`, `Perenco Uk Limited`, `Bp Exploration Operating Company Limited`, `Repsol Resources Uk Limited`, `Apache Beryl I Limited`, `Shell U.K. Limited` |
| `drilling_facility` | String | drilling facility | `Unknown`, `Deepsea Bergen`, `Transocean Arctic`, `Treasure Saga`, `Polar Pioneer`, `Bredford Dolphin`, `West Vanguard`, `Deepsea Stavanger`, `Ocean Vanguard`, `Borgland Dolphin` |
| `production_licence` | String | production licence | `01/62`, `050`, `018`, `089`, `053`, `01/35`, `054`, `120`, `128`, `006` |
| `country` | String | The country where the well is located | coded, see below |
| `formation_tops` | SmallInteger | formation tops | `1`, `0` |
| `geochem_info` | SmallInteger | geochemical information | `0`, `1` |
| `log` | SmallInteger | well logs | `1`, `0` |
| `mud` | SmallInteger | has mud records | `1`, `0` |
| `oil_samples` | SmallInteger | has oil samples | `0`, `1` |
| `wellbore_history` | SmallInteger | has wellbore history | `1`, `0` |
| `npd_papers` | SmallInteger | NPD papers | `0`, `1` |
| `cuttings_sample` | String | has cuttings samples | `YES`, `NO` |
| `core_sample` | String | has core samples | `YES`, `NO` |
| `content_type` | SmallInteger | content type | coded, see below |
| `geometry` | Point geometry | Point geometry in EPSG:4326 (longitude, latitude). |  |

# Codes

## `source`

| Code | Value |
|---|---|
| `NPD` | Norwegian Petroleum Directorate |
| `DECC` | Department of Energy & Climate Change |
| `DEA` | Danish Energy Agency |
| `NLOG` | NL Oil and GAS Portal |

## `country`

| Code | Value |
|---|---|
| `NO` | Norway |
| `UK` | United Kingdom |
| `DK` | Denmark |
| `NL` | Netherlands |

## `content_type`

| Code | Value |
|---|---|
| `0` | DRY |
| `1` | OIL |
| `2` | GAS |
| `4` | OIL SHOWS |
| `5` | OIL/GAS |
| `7` | GAS/CONDENSATE |
| `8` | GAS SHOWS |
| `9` | SHOWS |
| `10` | OIL/GAS SHOWS |
| `11` | GAS/CONDENSATE SHOWS |
| `12` | OIL/CONDENSATE SHOWS |
| `13` | OIL/GAS/CONDENSATE |
| `14` | WATER |
| `15` | OIL/CONDENSATE |
| `16` | UNKNOWN |
| `17` | SALT |

# Query hints

## `well_name`

Make sure to use the SQL ILIKE in the WHERE clause for the values of the column well_name. For example: given >>well name is 22/02b-<< becomes >>well_name ILIKE '%22/02b-%'<<

## `wellbore_name`

Make sure to use the SQL ILIKE in the WHERE clause for the values of the column wellbore_name. For example: given >>wellbore name is m-1x<< becomes >>wellbore_name ILIKE '%M-1X%'<<

## `purpose`

Make sure to uppercase the compared values of the column purpose in the where clause. For example: given the value >>exploration<< becomes >>EXPLORATION<<

## `field_name`

Make sure to uppercase the compared values of the column field_name in the where clause. For example: given the value >>troll<< becomes >>TROLL<<

## `multilateral`

Make sure to uppercase the compared values of the column multilateral in the where clause. For example: given the value >>no<< becomes >>NO<< Text for value YES: that are multilateral. Text for value NO: that are not multilateral.

## `status`

Make sure to uppercase the compared values of the column status in the where clause. For example: given the value >>abandoned phase 3<< becomes >>ABANDONED PHASE 3<<

## `water_depth`

ALWAYS use SQL CAST AS DOUBLE PRECISION when comparing a value with the column water_depth. Use 'water_depth = cast(110.0 as DOUBLE PRECISION)' for 'water depth is 110.0'.

## `production_facility`

Make sure to uppercase the compared values of the column production_facility in the where clause. For example: given the value >>varg a<< becomes >>VARG A<<

## `source`

Use 'source = 'NPD'' for 'norwegian petroleum directorate'. Use 'source = 'DECC'' for 'department of energy & climate change'. Use 'source = 'DEA'' for 'danish energy agency'. Use 'source = 'NLOG'' for 'nl oil and gas portal'. NEVER use SQL LIKE in the WHERE clause for the values of the column source.

## `well_type`

Make sure to uppercase the compared values of the column well_type in the where clause. For example: given the value >>exploration<< becomes >>EXPLORATION<<

## `discovery_wellbore`

Make sure to uppercase the compared values of the column discovery_wellbore in the where clause. For example: given the value >>no<< becomes >>NO<< Text for value YES: that are discovery wellbores. Text for value NO: that are not discovery wellbores.

## `drilling_operator`

Make sure to use the SQL ILIKE in the WHERE clause for the values of the column drilling_operator. For example: given >>drilling operator is unknown<< becomes >>drilling_operator ILIKE '%Unknown%'<<

## `drilling_facility`

Make sure to use the SQL ILIKE in the WHERE clause for the values of the column drilling_facility. For example: given >>drilling facility is unknown<< becomes >>drilling_facility ILIKE '%Unknown%'<<

## `production_licence`

Make sure to use the SQL ILIKE in the WHERE clause for the values of the column production_licence. For example: given >>production licence is 01/62<< becomes >>production_licence ILIKE '%01/62%'<<

## `country`

Use 'country = 'NO'' for 'norway'. Use 'country = 'UK'' for 'united kingdom'. Use 'country = 'DK'' for 'denmark'. Use 'country = 'NL'' for 'netherlands'. NEVER use SQL LIKE in the WHERE clause for the values of the column country.

## `formation_tops`

ALWAYS use SQL CAST AS SMALLINT when comparing a value with the column formation_tops. Use 'formation_tops = cast(1 as SMALLINT)' for 'formation tops is 1'.

## `geochem_info`

ALWAYS use SQL CAST AS SMALLINT when comparing a value with the column geochem_info. Use 'geochem_info = cast(0 as SMALLINT)' for 'geochemical information is 0'.

## `log`

ALWAYS use SQL CAST AS SMALLINT when comparing a value with the column log. Use 'log = cast(1 as SMALLINT)' for 'well logs is 1'.

## `mud`

ALWAYS use SQL CAST AS SMALLINT when comparing a value with the column mud. Use 'mud = cast(1 as SMALLINT)' for 'has mud records is 1'.

## `oil_samples`

ALWAYS use SQL CAST AS SMALLINT when comparing a value with the column oil_samples. Use 'oil_samples = cast(0 as SMALLINT)' for 'has oil samples is 0'.

## `wellbore_history`

ALWAYS use SQL CAST AS SMALLINT when comparing a value with the column wellbore_history. Use 'wellbore_history = cast(1 as SMALLINT)' for 'has wellbore history is 1'.

## `npd_papers`

ALWAYS use SQL CAST AS SMALLINT when comparing a value with the column npd_papers. Use 'npd_papers = cast(0 as SMALLINT)' for 'NPD papers is 0'.

## `cuttings_sample`

Make sure to uppercase the compared values of the column cuttings_sample in the where clause. For example: given the value >>yes<< becomes >>YES<< Text for value YES: with cuttings samples. Text for value NO: without cuttings samples.

## `core_sample`

Make sure to uppercase the compared values of the column core_sample in the where clause. For example: given the value >>yes<< becomes >>YES<< Text for value YES: with core samples. Text for value NO: without core samples.

## `content_type`

Use 'content_type = cast(0 as SMALLINT)' for 'dry'. Use 'content_type = cast(1 as SMALLINT)' for 'oil'. Use 'content_type = cast(2 as SMALLINT)' for 'gas'. Use 'content_type = cast(4 as SMALLINT)' for 'oil shows'. Use 'content_type = cast(5 as SMALLINT)' for 'oil/gas'. Use 'content_type = cast(7 as SMALLINT)' for 'gas/condensate'. Use 'content_type = cast(8 as SMALLINT)' for 'gas shows'. Use 'content_type = cast(9 as SMALLINT)' for 'shows'. Use 'content_type = cast(10 as SMALLINT)' for 'oil/gas shows'. Use 'content_type = cast(11 as SMALLINT)' for 'gas/condensate shows'. Use 'content_type = cast(12 as SMALLINT)' for 'oil/condensate shows'. Use 'content_type = cast(13 as SMALLINT)' for 'oil/gas/condensate'. Use 'content_type = cast(14 as SMALLINT)' for 'water'. Use 'content_type = cast(15 as SMALLINT)' for 'oil/condensate'. Use 'content_type = cast(16 as SMALLINT)' for 'unknown'. Use 'content_type = cast(17 as SMALLINT)' for 'salt'. ALWAYS use SQL CAST AS SMALLINT when comparing a value with the column content_type.

[^model]: Apache Ossie semantic model
